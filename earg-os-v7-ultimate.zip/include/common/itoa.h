#pragma once
#include <stdint.h>
void itoa_dec(char* buf, uint32_t v);
void itoa_hex(char* buf, uint32_t v);
