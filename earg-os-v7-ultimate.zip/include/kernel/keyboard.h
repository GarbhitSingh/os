#pragma once
#include <stdbool.h>
void keyboard_init(void);
bool keyboard_has_char(void);
char keyboard_get_char(void);
