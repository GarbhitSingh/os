#pragma once
void idt_init(void);
