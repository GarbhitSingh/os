#pragma once
#include <stddef.h>
#include <stdint.h>

void heap_init(uint32_t start, uint32_t size);
void* kmalloc(size_t size);
void kfree(void* ptr);
size_t heap_free_bytes(void);
