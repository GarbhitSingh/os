#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <kernel/multiboot.h>

typedef struct {
    uint32_t* addr;
    uint32_t width;
    uint32_t height;
    uint32_t pitch; // bytes per line
    uint32_t bpp;
} fb_info_t;

bool fb_init(multiboot_info_t* mb);
fb_info_t fb_get(void);

void fb_clear(uint32_t color);
void fb_putpixel(int x,int y,uint32_t color);
void fb_rect(int x,int y,int w,int h,uint32_t color);
