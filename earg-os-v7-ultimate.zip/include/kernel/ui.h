#pragma once
#include <stddef.h>
void ui_init(void);
void ui_tick(void);
void ui_keypress(char c);
void ui_log(const char* s);
