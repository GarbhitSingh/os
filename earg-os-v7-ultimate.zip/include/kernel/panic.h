#pragma once
void panic(const char* msg);
