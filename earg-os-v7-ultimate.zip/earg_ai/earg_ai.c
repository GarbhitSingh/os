#include <earg_ai/earg_ai.h>
#include <common/string.h>

// v1 frozen (fallback) + v2 embedded engine
typedef struct {
    char memory[512];
} divine_core_t;

static divine_core_t core;

static void remember(const char* k, const char* v){
    size_t m=strlen(core.memory), nk=strlen(k), nv=strlen(v);
    if(m+nk+nv+4 >= sizeof(core.memory)) return;
    memcpy(core.memory+m,k,nk); m+=nk;
    core.memory[m++]='=';
    memcpy(core.memory+m,v,nv); m+=nv;
    core.memory[m++]=';';
    core.memory[m]=0;
}

static const char* recall(const char* k){
    static char val[64];
    val[0]=0;
    const char* s=core.memory;
    size_t nk=strlen(k);
    for(size_t i=0;s[i];){
        size_t start=i;
        size_t eq=i;
        while(s[eq] && s[eq]!='=') eq++;
        if(!s[eq]) break;
        if((eq-start)==nk && strncmp(s+start,k,nk)==0){
            size_t p=eq+1, j=0;
            while(s[p] && s[p]!=';' && j<sizeof(val)-1) val[j++]=s[p++];
            val[j]=0; return val;
        }
        while(s[i] && s[i]!=';') i++;
        if(s[i]==';') i++;
    }
    return 0;
}

void earg_ai_init(void){
    core.memory[0]=0;
    remember("name","JARVIS");
    remember("os","EARG OS v5 TRUE");
    remember("mode","GUI");
}

static void respond(const char* s, char* out, size_t out_sz){
    if(!out||!out_sz) return;
    strncpy(out,s,out_sz-1);
    out[out_sz-1]=0;
}

static int starts(const char* s, const char* p){
    return strncmp(s,p,strlen(p))==0;
}

void earg_ai_on_user_input(const char* text, char* out, size_t out_sz){
    if(!text || !text[0]){ respond("...",out,out_sz); return; }

    // v2: intents
    if(strcmp(text,"hi")==0 || strcmp(text,"hello")==0){
        respond("Hello. Jarvis UI online.",out,out_sz); return;
    }
    if(strcmp(text,"who are you")==0){
        respond("I am JARVIS. Embedded assistant. Divine Core + Divine Engine online.",out,out_sz); return;
    }
    if(strcmp(text,"status")==0){
        const char* os=recall("os");
        if(os){
            char tmp[128]; tmp[0]=0;
            strcpy(tmp,"Running "); strncpy(tmp+8,os,110);
            respond(tmp,out,out_sz);
        } else respond("All systems stable.",out,out_sz);
        return;
    }
    if(starts(text,"remember ")){
        const char* kv=text+9;
        const char* eq=kv;
        while(*eq && *eq!='=') eq++;
        if(*eq!='='){ respond("Usage: remember key=value",out,out_sz); return; }
        char k[32]; char v[64];
        size_t nk=(size_t)(eq-kv); if(nk>=sizeof(k)) nk=sizeof(k)-1;
        memcpy(k,kv,nk); k[nk]=0;
        strncpy(v,eq+1,sizeof(v)-1); v[sizeof(v)-1]=0;
        remember(k,v);
        respond("Stored.",out,out_sz); return;
    }
    if(starts(text,"recall ")){
        const char* k=text+7;
        const char* v=recall(k);
        if(v) respond(v,out,out_sz);
        else respond("Not found.",out,out_sz);
        return;
    }

    // fallback / unknown
    respond("Acknowledged. Skill not installed yet.",out,out_sz);
}
