# EARG OS v6 FINAL — Jarvis Edition (GUI + Mouse + FAT32 Persistence)

This release includes:
- Bootable GRUB Multiboot ISO
- Framebuffer GUI @ 1280x720x32
- PSF font renderer
- Keyboard input + PS/2 mouse cursor (basic)
- Window-ish UI (Jarvis HUD + apps)
- FAT32 disk image (persistent) mounted in QEMU
- Jarvis memory persistence saved to FAT32

## Dependencies (WSL Ubuntu / Linux)
```bash
sudo apt update
sudo apt install -y build-essential nasm grub-pc-bin xorriso qemu-system-x86 dosfstools mtools
```

## Build + Run
```bash
make run
```

This runs QEMU with:
- ISO boot
- `disk.img` mounted as primary drive for FAT32 persistence

## Notes
- This is a hobby OS. It demonstrates a complete end-to-end OS pipeline and UI + storage + assistant integration.
