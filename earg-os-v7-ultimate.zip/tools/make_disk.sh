#!/usr/bin/env bash
set -euo pipefail

DISK="${1:-disk.img}"

if [ -f "$DISK" ]; then
  echo "[disk] $DISK already exists"
  exit 0
fi

echo "[disk] creating FAT32 disk image: $DISK"
dd if=/dev/zero of="$DISK" bs=1M count=64 status=none

# format FAT32
mkfs.fat -F 32 "$DISK" > /dev/null

# create initial files using mtools (no mount required)
mmd -i "$DISK" ::/EARG > /dev/null || true
echo "EARG OS v6 FINAL Disk" | mcopy -i "$DISK" - ::/EARG/README.TXT > /dev/null

echo "[disk] done"
