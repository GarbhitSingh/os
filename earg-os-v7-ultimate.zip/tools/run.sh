#!/usr/bin/env bash
set -euo pipefail
make iso disk
qemu-system-i386 -cdrom earg-os-v6-final.iso -drive file=disk.img,format=raw,if=ide -m 1024M -no-reboot -vga std
