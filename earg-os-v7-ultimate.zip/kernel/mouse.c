#include <kernel/mouse.h>
#include <kernel/isr.h>
#include <common/ports.h>

static volatile int dx_acc=0, dy_acc=0;
static volatile bool l=false, r=false, m=false;
static volatile bool has=false;

static uint8_t packet[3];
static uint8_t cycle=0;

static void mouse_wait(uint8_t type){
    uint32_t t=100000;
    if(type==0){
        while(t--){
            if((inb(0x64) & 1)==1) return;
        }
    }else{
        while(t--){
            if((inb(0x64) & 2)==0) return;
        }
    }
}
static void mouse_write(uint8_t data){
    mouse_wait(1);
    outb(0x64, 0xD4);
    mouse_wait(1);
    outb(0x60, data);
}
static uint8_t mouse_read(void){
    mouse_wait(0);
    return inb(0x60);
}

static void mouse_callback(registers_t* rgs){
    (void)rgs;
    uint8_t data = inb(0x60);

    switch(cycle){
        case 0:
            packet[0]=data;
            if(!(packet[0] & 0x08)) return; // sync
            cycle=1;
            break;
        case 1:
            packet[1]=data;
            cycle=2;
            break;
        case 2:
            packet[2]=data;
            cycle=0;

            l = packet[0] & 1;
            r = packet[0] & 2;
            m = packet[0] & 4;

            int x = (int8_t)packet[1];
            int y = (int8_t)packet[2];

            dx_acc += x;
            dy_acc -= y;
            has=true;
            break;
    }
}

void mouse_init(void){
    // enable aux device
    mouse_wait(1);
    outb(0x64, 0xA8);

    // enable interrupts
    mouse_wait(1);
    outb(0x64, 0x20);
    mouse_wait(0);
    uint8_t status = inb(0x60) | 2;
    mouse_wait(1);
    outb(0x64, 0x60);
    mouse_wait(1);
    outb(0x60, status);

    // defaults
    mouse_write(0xF6);
    mouse_read();
    // enable streaming
    mouse_write(0xF4);
    mouse_read();

    // IRQ12 -> interrupt 44 (32+12)
    isr_register_handler(44, mouse_callback);
}

bool mouse_has_event(void){ return has; }

void mouse_get(int* dx, int* dy, bool* left, bool* right, bool* middle){
    if(dx) *dx=dx_acc;
    if(dy) *dy=dy_acc;
    if(left) *left=l;
    if(right) *right=r;
    if(middle) *middle=m;

    dx_acc=0; dy_acc=0;
    has=false;
}
