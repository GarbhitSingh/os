#include <kernel/panic.h>
#include <kernel/vga.h>

void panic(const char* msg){
    vga_set_color(15, 4);
    vga_writeln("");
    vga_writeln("=== KERNEL PANIC ===");
    vga_writeln(msg);
    while(1){ __asm__ volatile("cli; hlt"); }
}
