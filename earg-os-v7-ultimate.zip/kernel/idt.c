#include <kernel/idt.h>
#include <kernel/isr.h>
#include <kernel/pic.h>
#include <common/types.h>
#include <common/string.h>

extern uint32_t isr_stub_table[];

typedef struct {
    uint16_t base_lo;
    uint16_t sel;
    uint8_t  always0;
    uint8_t  flags;
    uint16_t base_hi;
} __attribute__((packed)) idt_entry_t;

typedef struct {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed)) idt_ptr_t;

static idt_entry_t idt[256];
static idt_ptr_t idtp;

extern void idt_flush(uint32_t);

static void idt_set_gate(uint8_t num, uint32_t base, uint16_t sel, uint8_t flags){
    idt[num].base_lo = base & 0xFFFF;
    idt[num].base_hi = (base >> 16) & 0xFFFF;
    idt[num].sel = sel;
    idt[num].always0 = 0;
    idt[num].flags = flags;
}

__attribute__((naked)) void idt_flush(uint32_t ptr){
    __asm__ volatile(
        "lidt (%0)\n"
        "sti\n"
        "ret\n" : : "r"(ptr)
    );
}

void idt_init(void){
    memset(idt, 0, sizeof(idt_entry_t)*256);

    idtp.limit = (sizeof(idt_entry_t)*256)-1;
    idtp.base  = (uint32_t)&idt;

    // 0-47 stubs in table (exceptions+IRQs)
    for(int i=0;i<48;i++){
        idt_set_gate((uint8_t)i, isr_stub_table[i], 0x08, 0x8E);
    }

    // remap PIC to 32-47
    pic_remap(0x20, 0x28);

    idt_flush((uint32_t)&idtp);
}
