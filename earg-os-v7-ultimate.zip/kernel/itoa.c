#include <common/itoa.h>

void itoa_dec(char* buf, unsigned int v){
    char tmp[16];
    int i=0;
    if(v==0){ buf[0]='0'; buf[1]=0; return; }
    while(v>0 && i<15){
        tmp[i++] = '0' + (v%10);
        v/=10;
    }
    int j=0;
    while(i>0) buf[j++]=tmp[--i];
    buf[j]=0;
}
void itoa_hex(char* buf, unsigned int v){
    const char* h="0123456789ABCDEF";
    buf[0]='0'; buf[1]='x';
    for(int i=0;i<8;i++){
        buf[2+i]=h[(v>>(28-4*i))&0xF];
    }
    buf[10]=0;
}
