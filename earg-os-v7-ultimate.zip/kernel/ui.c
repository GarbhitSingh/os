#include <kernel/ui.h>
#include <kernel/fb.h>
#include <kernel/psf.h>
#include <kernel/timer.h>
#include <kernel/heap.h>
#include <common/string.h>

static char chat_log[2048];
static size_t chat_len=0;

static char input_line[128];
static size_t input_len=0;

static uint32_t C_BG   = 0xFF05080D;
static uint32_t C_CYAN = 0xFF00E5FF;
static uint32_t C_DIM  = 0xFF0F1A22;
static uint32_t C_TEXT = 0xFFE6F1FF;
static uint32_t C_ACC  = 0xFF00B3FF;

void ui_log(const char* s){
    size_t n=strlen(s);
    if(n+chat_len+2 >= sizeof(chat_log)){
        chat_len=0;
        chat_log[0]=0;
    }
    memcpy(chat_log+chat_len, s, n);
    chat_len += n;
    chat_log[chat_len++]='\n';
    chat_log[chat_len]=0;
}

static void hud_draw(void){
    fb_info_t fb = fb_get();
    fb_clear(C_BG);

    // Top bar
    fb_rect(0,0,(int)fb.width,36,C_DIM);
    psf_draw_text(16,10,"EARG OS v5 - JARVIS EDITION", C_CYAN, C_DIM);

    char buf[64];
    buf[0]=0;

    // right side: ticks + heap
    // crude print
    psf_draw_text((int)fb.width-320,10,"ticks:",C_TEXT,C_DIM);
    extern void itoa_dec(char*, unsigned int);
    itoa_dec(buf, timer_ticks());
    psf_draw_text((int)fb.width-260,10,buf,C_TEXT,C_DIM);

    psf_draw_text((int)fb.width-180,10,"heap:",C_TEXT,C_DIM);
    itoa_dec(buf, (unsigned int)heap_free_bytes());
    psf_draw_text((int)fb.width-120,10,buf,C_TEXT,C_DIM);

    // Side panel
    fb_rect(0,36,280,(int)fb.height-36,C_DIM);
    psf_draw_text(16,56,"SYSTEMS",C_ACC,C_DIM);
psf_draw_text(16,160,"APPS",C_ACC,C_DIM);
psf_draw_text(16,184,"[1] CHAT", active_app==0?C_CYAN:C_TEXT, C_DIM);
psf_draw_text(16,204,"[2] TERM", active_app==1?C_CYAN:C_TEXT, C_DIM);
psf_draw_text(16,224,"[3] FILES", active_app==2?C_CYAN:C_TEXT, C_DIM);

    psf_draw_text(16,80,"- Divine Core: OK",C_TEXT,C_DIM);
    psf_draw_text(16,100,"- Divine Engine: OK",C_TEXT,C_DIM);
    psf_draw_text(16,120,"- EARG AI v2: OK",C_TEXT,C_DIM);

    // Main console panel
    int main_x=300;
    int main_y=60;
    int main_w=(int)fb.width-main_x-20;
    int main_h=(int)fb.height-main_y-80;
    fb_rect(main_x,main_y,main_w,main_h,0xFF07121A);
    fb_rect(main_x,main_y,main_w,2,C_CYAN);

    psf_draw_text(main_x+16,main_y+16, active_app==0?"JARVIS CONSOLE":(active_app==1?"TERMINAL":"FILES"), C_CYAN,0xFF07121A);

    // chat text area
    if(active_app==0){
  psf_draw_text(main_x+16,main_y+44, chat_log, C_TEXT, 0xFF07121A);
} else if(active_app==1){
  psf_draw_text(main_x+16,main_y+44, "term> help\ncommands: help, mem\n(placeholder app)", C_TEXT, 0xFF07121A);
} else {
  psf_draw_text(main_x+16,main_y+44, "files:\nEARG/README.TXT\n(placeholder FAT32 browser)", C_TEXT, 0xFF07121A);
}


    // input box
    int in_y=(int)fb.height-56;
    fb_rect(main_x,in_y,main_w,40,0xFF061018);
    fb_rect(main_x,in_y,main_w,2,C_CYAN);
    psf_draw_text(main_x+16,in_y+12,"> ",C_CYAN,0xFF061018);
    psf_draw_text(main_x+40,in_y+12,input_line,C_TEXT,0xFF061018);
}

void ui_init(void){
    ui_log("Jarvis UI online.");
    ui_log("Type: hi | who are you | status");
    ui_log("Also: remember key=value | recall key");
}

void ui_keypress(char c){
    if(c=='\n'){
        input_line[input_len]=0;
        ui_log("YOU:");
        ui_log(input_line);
        input_len=0;
        input_line[0]=0;
        return;
    }
    if(c=='\b'){
        if(input_len>0){ input_len--; input_line[input_len]=0; }
        return;
    }
    if(input_len < sizeof(input_line)-1 && c>=32 && c<127){
        input_line[input_len++]=c;
        input_line[input_len]=0;
    }
}

const char* ui_get_input(void){
    return input_line;
}

#include <kernel/mouse.h>

static int curx=640, cury=360;
static int active_app=0; // 0=chat 1=terminal 2=files
static int last_click=0;

static void draw_cursor(){
    // simple cross cursor
    for(int i=-6;i<=6;i++){
        fb_putpixel(curx+i, cury, 0xFFFFFFFF);
        fb_putpixel(curx, cury+i, 0xFFFFFFFF);
    }
}

void ui_tick(void){
    // update mouse
    if(mouse_has_event()){
        int dx,dy; bool l,r,m;
        mouse_get(&dx,&dy,&l,&r,&m);
        curx += dx;
        cury += dy;
        fb_info_t fb = fb_get();
        if(curx<0) curx=0;
        if(cury<40) cury=40;
        if(curx>(int)fb.width-1) curx=fb.width-1;
        if(cury>(int)fb.height-1) cury=fb.height-1;
        if(l) ui_log("[mouse] left click");
    }
    hud_draw();
    draw_cursor();
}
