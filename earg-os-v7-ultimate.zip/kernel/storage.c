#include <common/types.h>
#include <kernel/ui.h>

// Placeholder for v6 FINAL storage layer.
// True ATA PIO + FAT32 read/write requires a larger codebase.
// This module provides a stable API surface for future expansion.

void storage_init(void){
    ui_log("[storage] FAT32 disk present (handled by tool disk.img).");
}
