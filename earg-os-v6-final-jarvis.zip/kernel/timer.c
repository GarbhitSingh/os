#include <kernel/timer.h>
#include <kernel/isr.h>
#include <common/ports.h>

static volatile uint32_t ticks = 0;

static void timer_callback(registers_t* r){
    (void)r;
    ticks++;
}

uint32_t timer_ticks(void){ return ticks; }

void timer_sleep(uint32_t t){
    uint32_t target = ticks + t;
    while(ticks < target){
        __asm__ volatile("hlt");
    }
}

void timer_init(uint32_t freq_hz){
    // PIT frequency = 1193180
    uint32_t divisor = 1193180 / freq_hz;
    outb(0x43, 0x36);
    outb(0x40, (uint8_t)(divisor & 0xFF));
    outb(0x40, (uint8_t)((divisor >> 8) & 0xFF));

    isr_register_handler(32, timer_callback);
}
