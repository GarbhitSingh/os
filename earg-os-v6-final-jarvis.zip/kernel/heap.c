#include <kernel/heap.h>
#include <common/string.h>
#include <common/types.h>

typedef struct block {
    uint32_t size;
    uint32_t free;
    struct block* next;
} block_t;

static block_t* heap_head = 0;
static uint32_t heap_end = 0;

void heap_init(uint32_t start, uint32_t size){
    heap_head = (block_t*)start;
    heap_head->size = size - sizeof(block_t);
    heap_head->free = 1;
    heap_head->next = 0;
    heap_end = start + size;
}

static void split(block_t* b, uint32_t size){
    if(b->size <= size + sizeof(block_t) + 8) return;
    block_t* n = (block_t*)((uint8_t*)b + sizeof(block_t) + size);
    n->size = b->size - size - sizeof(block_t);
    n->free = 1;
    n->next = b->next;
    b->size = size;
    b->next = n;
}

void* kmalloc(size_t size){
    if(size==0) return 0;
    // align 8
    size = (size + 7) & ~7;

    for(block_t* b=heap_head; b; b=b->next){
        if(b->free && b->size >= size){
            split(b, (uint32_t)size);
            b->free = 0;
            return (uint8_t*)b + sizeof(block_t);
        }
    }
    return 0;
}

static void merge(){
    for(block_t* b=heap_head; b && b->next; b=b->next){
        if(b->free && b->next->free){
            b->size += sizeof(block_t) + b->next->size;
            b->next = b->next->next;
        }
    }
}

void kfree(void* ptr){
    if(!ptr) return;
    block_t* b = (block_t*)((uint8_t*)ptr - sizeof(block_t));
    b->free = 1;
    merge();
}

size_t heap_free_bytes(void){
    size_t sum=0;
    for(block_t* b=heap_head; b; b=b->next){
        if(b->free) sum += b->size;
    }
    return sum;
}
