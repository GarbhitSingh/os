#include <kernel/fb.h>
#include <kernel/panic.h>

static fb_info_t fb;

bool fb_init(multiboot_info_t* mb){
    if(!mb) return false;
    // flag 12 => framebuffer info available (bit 12)
    if(!(mb->flags & (1<<12))) return false;

    fb.addr = (uint32_t*)(uint32_t)mb->framebuffer_addr;
    fb.width = mb->framebuffer_width;
    fb.height = mb->framebuffer_height;
    fb.pitch = mb->framebuffer_pitch;
    fb.bpp = mb->framebuffer_bpp;

    if(!fb.addr || fb.bpp != 32) return false;
    return true;
}

fb_info_t fb_get(void){ return fb; }

void fb_clear(uint32_t color){
    for(uint32_t y=0;y<fb.height;y++){
        uint32_t* row = (uint32_t*)((uint8_t*)fb.addr + y*fb.pitch);
        for(uint32_t x=0;x<fb.width;x++) row[x]=color;
    }
}

void fb_putpixel(int x,int y,uint32_t color){
    if(x<0||y<0) return;
    if((uint32_t)x>=fb.width || (uint32_t)y>=fb.height) return;
    uint32_t* row = (uint32_t*)((uint8_t*)fb.addr + (uint32_t)y*fb.pitch);
    row[(uint32_t)x]=color;
}

void fb_rect(int x,int y,int w,int h,uint32_t color){
    for(int yy=0;yy<h;yy++){
        int py=y+yy;
        if(py<0 || (uint32_t)py>=fb.height) continue;
        uint32_t* row = (uint32_t*)((uint8_t*)fb.addr + (uint32_t)py*fb.pitch);
        for(int xx=0;xx<w;xx++){
            int px=x+xx;
            if(px<0 || (uint32_t)px>=fb.width) continue;
            row[(uint32_t)px]=color;
        }
    }
}
