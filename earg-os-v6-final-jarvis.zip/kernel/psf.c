#include <kernel/psf.h>
#include <kernel/fb.h>
#include <common/string.h>

static const psf1_header_t* hdr = 0;
static const uint8_t* glyphs = 0;

void psf_init(const void* font_blob){
    hdr = (const psf1_header_t*)font_blob;
    glyphs = (const uint8_t*)font_blob + sizeof(psf1_header_t);
}

void psf_draw_char(int x,int y,char c,uint32_t fg,uint32_t bg){
    fb_info_t fb = fb_get();
    if(!hdr || !glyphs || !fb.addr) return;

    const uint8_t* g = glyphs + ((uint8_t)c) * hdr->charsize;
    for(int row=0; row<hdr->charsize; row++){
        uint8_t bits = g[row];
        for(int col=0; col<8; col++){
            uint32_t color = (bits & (0x80 >> col)) ? fg : bg;
            fb_putpixel(x+col, y+row, color);
        }
    }
}

void psf_draw_text(int x,int y,const char* s,uint32_t fg,uint32_t bg){
    int cx=x;
    int cy=y;
    for(size_t i=0; s && s[i]; i++){
        if(s[i]=='\n'){ cy += hdr? hdr->charsize:16; cx=x; continue; }
        psf_draw_char(cx, cy, s[i], fg, bg);
        cx += 8;
    }
}
