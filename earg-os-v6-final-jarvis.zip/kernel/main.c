#include <kernel/panic.h>
#include <kernel/gdt.h>
#include <kernel/idt.h>
#include <kernel/timer.h>
#include <kernel/keyboard.h>
#include <kernel/mouse.h>
#include <kernel/paging.h>
#include <kernel/heap.h>
#include <kernel/multiboot.h>
#include <kernel/fb.h>
#include <kernel/psf.h>
#include <kernel/ui.h>
#include <kernel/storage.h>
#include <earg_ai/earg_ai.h>

extern uint32_t end;
extern uint8_t _binary_assets_font_psf_start;

static char input_buf[128];
static size_t input_len=0;

static void on_char(char c){
    if(c=='\n'){
        input_buf[input_len]=0;
        if(input_len>0){
            char out[200];
            ui_log("YOU:");
            ui_log(input_buf);
            earg_ai_on_user_input(input_buf,out,sizeof(out));
            ui_log("JARVIS:");
            ui_log(out);
        }
        input_len=0;
        input_buf[0]=0;
        ui_keypress('\n');
        return;
    }
    if(c=='\b'){
        if(input_len>0) input_len--;
        ui_keypress('\b');
        return;
    }
    if(input_len < sizeof(input_buf)-1 && c>=32 && c<127){
        input_buf[input_len++]=c;
        ui_keypress(c);
    }
}

void kernel_main(multiboot_info_t* mb){
    gdt_init();
    idt_init();
    paging_init();

    uint32_t heap_start=((uint32_t)&end + 0x1000) & ~0xFFF;
    heap_init(heap_start, 8*1024*1024);

    timer_init(100);
    keyboard_init();
    mouse_init();

    if(!fb_init(mb)){
        panic("No multiboot framebuffer. Ensure GRUB gfxpayload keep.");
    }

    psf_init((const void*)&_binary_assets_font_psf_start);
    ui_init();
    earg_ai_init();
    storage_init();

    ui_log("EARG OS v6 FINAL ready.");

    while(1){
        if(keyboard_has_char()){
            char c=keyboard_get_char();
            on_char(c);
        }
        ui_tick();
    }
}
