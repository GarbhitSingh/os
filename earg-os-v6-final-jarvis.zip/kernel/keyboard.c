#include <kernel/keyboard.h>
#include <kernel/isr.h>
#include <common/ports.h>

#define KBD_DATA 0x60

static volatile char buf[256];
static volatile int head=0, tail=0;

static const char scancode_to_ascii[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', '',
    '	','q','w','e','r','t','y','u','i','o','p','[',']','
', 0,
    'a','s','d','f','g','h','j','k','l',';','\'', '`', 0,'\\',
    'z','x','c','v','b','n','m',',','.','/', 0,'*',0,' ',
};

static void push_char(char c){
    int next = (head+1) & 255;
    if(next==tail) return;
    buf[head] = c;
    head = next;
}

static void keyboard_callback(registers_t* r){
    (void)r;
    uint8_t sc = inb(KBD_DATA);
    if(sc & 0x80) return; // key release
    if(sc < 128){
        char c = scancode_to_ascii[sc];
        if(c) push_char(c);
    }
}

void keyboard_init(void){
    isr_register_handler(33, keyboard_callback);
}

bool keyboard_has_char(void){
    return head != tail;
}

char keyboard_get_char(void){
    while(!keyboard_has_char()){
        __asm__ volatile("hlt");
    }
    char c = buf[tail];
    tail = (tail+1) & 255;
    return c;
}
