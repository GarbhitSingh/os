#include <kernel/paging.h>
#include <kernel/panic.h>
#include <common/types.h>
#include <common/string.h>

static uint32_t* page_directory = (uint32_t*)0x9C000;
static uint32_t* first_page_table = (uint32_t*)0x9D000;

static inline void load_page_directory(uint32_t* pd){
    __asm__ volatile("mov %0, %%cr3" : : "r"(pd));
}
static inline void enable_paging(void){
    uint32_t cr0;
    __asm__ volatile("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;
    __asm__ volatile("mov %0, %%cr0" : : "r"(cr0));
}

void paging_init(void){
    memset(page_directory, 0, 4096);
    memset(first_page_table, 0, 4096);

    // identity map first 4MB
    for(uint32_t i=0;i<1024;i++){
        first_page_table[i] = (i*0x1000) | 3;
    }
    page_directory[0] = ((uint32_t)first_page_table) | 3;

    load_page_directory(page_directory);
    enable_paging();
}
