#include <kernel/isr.h>
#include <kernel/vga.h>
#include <kernel/panic.h>
#include <kernel/pic.h>
#include <common/types.h>

static isr_t handlers[256] = {0};

void isr_register_handler(uint8_t n, isr_t handler){
    handlers[n] = handler;
}

static const char* exc_msgs[] = {
 "Divide By Zero","Debug","Non Maskable Interrupt","Breakpoint","Into Detected Overflow",
 "Out of Bounds","Invalid Opcode","No Coprocessor","Double Fault","Coprocessor Segment Overrun",
 "Bad TSS","Segment Not Present","Stack Fault","General Protection Fault","Page Fault",
 "Unknown Interrupt","Coprocessor Fault","Alignment Check","Machine Check","Reserved",
 "Reserved","Reserved","Reserved","Reserved","Reserved","Reserved","Reserved","Reserved",
 "Reserved","Reserved","Reserved","Reserved"
};

void isr_handler(registers_t* r){
    if(handlers[r->int_no]){
        handlers[r->int_no](r);
        return;
    }
    if(r->int_no < 32){
        vga_writeln("");
        vga_writeln("CPU EXCEPTION:");
        vga_write(exc_msgs[r->int_no]);
        vga_write("  INT=");
        vga_write_dec(r->int_no);
        vga_write(" ERR=");
        vga_write_hex(r->err_code);
        vga_writeln("");
        panic("Unhandled CPU exception");
    }
}

void irq_handler(registers_t* r){
    uint8_t irq = (uint8_t)(r->int_no - 32);

    if(handlers[r->int_no]){
        handlers[r->int_no](r);
    }

    pic_send_eoi(irq);
}
