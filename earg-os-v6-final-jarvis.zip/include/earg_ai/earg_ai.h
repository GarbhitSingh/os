#pragma once
#include <stddef.h>
void earg_ai_init(void);
void earg_ai_on_user_input(const char* text, char* out, size_t out_sz);
