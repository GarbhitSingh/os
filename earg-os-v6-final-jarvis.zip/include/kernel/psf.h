#pragma once
#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint8_t magic[2];
    uint8_t mode;
    uint8_t charsize;
} __attribute__((packed)) psf1_header_t;

void psf_init(const void* font_blob);
void psf_draw_char(int x,int y,char c,uint32_t fg,uint32_t bg);
void psf_draw_text(int x,int y,const char* s,uint32_t fg,uint32_t bg);
