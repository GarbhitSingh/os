#pragma once
#include <stdbool.h>
void mouse_init(void);
bool mouse_has_event(void);
void mouse_get(int* dx, int* dy, bool* left, bool* right, bool* middle);
