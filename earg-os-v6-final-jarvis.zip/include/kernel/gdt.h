#pragma once
void gdt_init(void);
