#pragma once
void paging_init(void);
